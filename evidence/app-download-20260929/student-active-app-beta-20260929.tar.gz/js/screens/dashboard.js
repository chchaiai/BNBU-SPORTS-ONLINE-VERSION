import{t,tx,currentLocale,getLanguage}from"../i18n.js";import{icon}from"../icons.js";import{esc}from"../ui.js";import{resolvePublicReasonModel}from"../v81-review.js";import{proofTodoContext}from"../proof-todo.js";import{canStartExercise,hasSubmittedCheckInToday,loadSession,sessionDurationMs,formatTimer}from"../session.js";import{joinRequestEntryPanel}from"./join.js";function homeCard(contentHtml,padding=18){return`<div class="swiss-panel" style="padding:${padding}px">${contentHtml}</div>`}function homeStatusPill(text,emphasized){return`<span class="home-pill${emphasized?" emphasized":""}">${esc(text)}</span>`}function homeProgressBar(value,total,height){const progress=total<=0?0:Math.min(Math.max(value/total,0),1);return`<div class="home-progress" style="height:${height}px"><div class="fill" style="width:${progress*100}%"></div></div>`}function formatMinutesFromHours(value){const minutes=Math.round((Number(value)||0)*60);return tx(`${minutes} 分钟`,`${minutes} min`)}function categoryMetric({title,value,target}){const targetText=Number.isFinite(target)?formatMinutesFromHours(target):tx("同步中","Syncing");return`<div class="col">
    <div class="row home-category-metric" style="gap:12px">
      <span class="title-medium text-on-surface grow" style="font-weight:500">${esc(title)}</span>
      <span class="body-medium text-on-surface" style="font-weight:500">${formatMinutesFromHours(value)} / ${esc(targetText)}</span>
    </div>
  </div>`}function derivedProgress(app){const progress=app.state.workspace.progress;const rule=app.state.workspace.hourRule;const hasAuthoritativeTotal=Number.isFinite(progress.totalValidHours);const hasAuthoritativeTarget=Number.isFinite(rule.total)&&rule.total>0;const totalCompleted=hasAuthoritativeTotal?Math.max(progress.totalValidHours,0):0;return{hasAuthoritativeTotal,hasAuthoritativeTarget,isQualified:progress.qualificationStatus==="QUALIFIED",totalCompleted,totalRemaining:hasAuthoritativeTotal&&hasAuthoritativeTarget?Math.max(0,rule.total-totalCompleted):null,completionRatio:hasAuthoritativeTotal&&hasAuthoritativeTarget?Math.min(1,totalCompleted/rule.total):0}}export function dashboardProgressStatusLabel(studentStatus,progressStatus){const membership=String(studentStatus??"").trim().toUpperCase();if(membership==="PENDING")return tx("已退班","Withdrawn");if(membership!=="ACTIVE")return tx("状态未知","Status unavailable");const progress=String(progressStatus??"").trim().toUpperCase();if(["COMPLETED","QUALIFIED","已达标"].includes(progress)){return tx("已达标","Completed")}return tx("进行中","In progress")}export function renderDashboard(app){const workspace=app.state.workspace;const student=workspace.student;const unread=app.unreadNoticeCount();const d=derivedProgress(app);const hasEnrollment=app.hasActiveEnrollment();const hasCheckedIn=hasSubmittedCheckInToday(workspace);const header=`<div class="row" style="gap:16px">
    <div class="col grow" style="gap:4px">
      <span class="headline-large ellipsis" style="color:var(--color-on-surface);font-weight:700">${t("dashboard_greeting",esc(student.name))}</span>
      <span class="body-medium text-muted ellipsis">${esc(student.id)}</span>
    </div>
    <span class="bell-wrap">
      <button class="bell-btn pressable" data-action="dashboard.openNotifications" aria-label="${t("dashboard_open_notifications")}">
        ${icon("notifications",22)}
      </button>
      ${unread>0?`<span class="bell-badge">${unread>99?"99+":unread}</span>`:""}
    </span>
  </div>`;let todayPanel="";if(hasEnrollment){const timeWindow=workspace.checkInTimeWindow;const serverCheck=app.isApiMode();const isLoadingPolicy=!serverCheck&&timeWindow.windowMode==="unavailable";const blockedReason=serverCheck||isLoadingPolicy?null:canStartExercise(timeWindow);const canStart=!isLoadingPolicy&&blockedReason===null;const stateColor=isLoadingPolicy?["var(--color-surface-variant)","var(--color-on-surface-variant)"]:canStart?["var(--color-primary-container)","var(--color-on-primary-container)"]:["var(--color-error-container)","var(--color-on-error-container)"];const windowTitle=serverCheck?tx("选择运动，开始今日打卡","Choose an activity to check in today"):isLoadingPolicy?tx("正在同步打卡时间窗","Syncing check-in hours"):canStart?tx("当前可开始运动","You can start exercising now"):tx("当前不可开始运动","You cannot start exercising now");const windowDetail=serverCheck?tx("请在老师设置的开放时间内运动并上传凭证","Exercise during your course hours and upload your evidence"):isLoadingPolicy?tx("加载完成后将显示当前状态","Your current status will appear once loading finishes."):canStart?timeWindow.dailyStartTime===null&&timeWindow.dailyEndTime===null?tx("老师设置为全天可打卡","Your teacher allows check-in all day"):tx(`每日打卡时间 ${timeWindow.dailyStartTime}–${timeWindow.dailyEndTime}`,`Daily check-in hours ${timeWindow.dailyStartTime}–${timeWindow.dailyEndTime}`):blockedReason||"";const pillText=serverCheck?tx("今日运动","Today’s activity"):isLoadingPolicy?tx("同步中","Syncing"):canStart?tx("可开始","Available"):tx("不可开始","Unavailable");todayPanel=homeCard(`
      <div class="row" style="gap:12px">
        <span class="title-large text-on-surface grow">${t("dashboard_today_checkin")}</span>
        ${hasCheckedIn?`<span class="text-primary" style="display:inline-flex">${icon("check-circle",22)}</span>`:""}
      </div>
      <div style="height:16px"></div>
      <div class="headline-small text-on-surface">${t(hasCheckedIn?"dashboard_today_checkin_complete":"dashboard_today_checkin_pending")}</div>
      <div style="height:6px"></div>
      <div class="body-medium text-muted">${t(hasCheckedIn?"dashboard_today_checkin_complete_hint":"dashboard_today_checkin_pending_hint")}</div>
      <div style="height:16px"></div>
      <div class="row" style="gap:10px">
        <span class="window-icon" style="--window-icon-bg:${stateColor[0]};--window-icon-color:${stateColor[1]}">${icon("timer",20)}</span>
        <div class="col grow">
          <span class="body-medium text-on-surface" style="font-weight:500">${esc(windowTitle)}</span>
          <span class="body-small text-muted">${esc(windowDetail)}</span>
        </div>
        <span class="home-pill" style="background:${stateColor[0]};color:${stateColor[1]};font-weight:600">${esc(pillText)}</span>
      </div>
      <div style="height:20px"></div>
      <button class="primary-btn pressable" data-action="dashboard.openCheckIn">${icon("add-box",20)}<span>${hasCheckedIn?tx("打开打卡","Open check-in"):t("dashboard_start_checkin")}</span></button>
    `,20)}const request=workspace.courseJoinRequest;const hasPendingJoinRequest=request&&request.status!=="ACTIVE";let joinPanel="";if(hasPendingJoinRequest){joinPanel=joinRequestEntryPanel(request)}else if(!hasEnrollment){joinPanel=homeCard(`
      <div class="title-large text-on-surface">${t("dashboard_join_course")}</div>
      <div style="height:8px"></div>
      <div class="body-medium text-muted">${t("dashboard_join_course_hint")}</div>
      <div style="height:8px"></div>
      <div class="body-small text-muted">${tx("加入成功后即为有效成员，无需教师审批。已开始的同一次入班可使用服务器 10 分钟宽限，且不得刷新续期。","A successful join is an active membership with no teacher approval. A join already started may use the server 10-minute grace period, which cannot be refreshed.")}</div>
      <div style="height:12px"></div>
      <div style="height:20px"></div>
      <button class="primary-btn pressable" data-action="dashboard.scanJoin">${icon("qr-code-scanner",20)}<span>${t("login_scan_button")}</span></button>
      <div style="height:4px"></div>
      <button class="text-btn pressable" data-action="dashboard.enterCode" style="width:100%;min-height:48px">
        ${icon("text-fields",18)}<span class="label-large">${t("dashboard_enter_invite")}</span>
      </button>
    `)}const session=loadSession(student.id);let resumePanel="";if(session&&(session.phase==="active"||session.phase==="paused")){const duration=sessionDurationMs(session);const startTime=new Date(session.startedAt).toLocaleTimeString(currentLocale(),{hour:"2-digit",minute:"2-digit",hour12:false});resumePanel=homeCard(`
      <div class="row" style="gap:10px">
        <span class="text-primary" style="display:inline-flex">${icon("timer",22)}</span>
        <span class="title-large text-on-surface">${t("dashboard_exercise_in_progress")}</span>
      </div>
      <div style="height:16px"></div>
      <div class="row"><span class="body-medium text-muted">${t("dashboard_exercise_start_time")}</span><span class="grow"></span><span class="body-medium text-on-surface" style="font-weight:500">${startTime}</span></div>
      <div style="height:10px"></div>
      <div class="row"><span class="body-medium text-muted">${t("dashboard_exercise_duration")}</span><span class="grow"></span><span class="body-medium text-on-surface" style="font-weight:500" data-dashboard-duration>${formatTimer(duration)}</span></div>
      <div style="height:20px"></div>
      <button class="primary-btn pressable" data-action="dashboard.openCheckIn">${icon("timer",20)}<span>${t("dashboard_exercise_continue")}</span></button>
    `)}const completionPercent=Math.floor(d.completionRatio*100);const overview=homeCard(`
    <div class="row" style="gap:12px">
      <span class="title-large text-on-surface grow">${t("dashboard_progress")}</span>
      ${homeStatusPill(dashboardProgressStatusLabel(student.status,workspace.progress.status),String(student.status??"").trim().toUpperCase()==="ACTIVE"&&d.isQualified)}
    </div>
    <div style="height:20px"></div>
    <div class="body-small text-muted">${t("dashboard_total_completed")}</div>
    <div class="home-progress-values">
      <span class="home-progress-value">${d.hasAuthoritativeTotal?Math.round(d.totalCompleted*60):"—"}</span>
      <span class="home-progress-unit">${tx("分钟","min")}</span>
    </div>
    <div class="home-progress-meta">
      <span>${tx("学期目标","Semester goal")} · ${d.hasAuthoritativeTarget?formatMinutesFromHours(workspace.hourRule.total):tx("同步中","Syncing")}</span>
      <strong>${d.hasAuthoritativeTotal?`${completionPercent}%`:"—"}</strong>
    </div>
    <div style="height:12px"></div>
    ${homeProgressBar(d.totalCompleted,d.hasAuthoritativeTarget?workspace.hourRule.total:0,8)}
    <div style="height:12px"></div>
    <div class="body-medium" style="color:${d.isQualified?"var(--color-primary)":"var(--color-on-surface-variant)"};font-weight:${d.isQualified?500:400}">
      ${!d.hasAuthoritativeTotal?tx("正在同步有效运动时长。","Syncing your valid exercise time."):!d.hasAuthoritativeTarget?tx("运动时长已更新，学期目标同步中。","Exercise time updated. Syncing your semester goal."):d.isQualified?t("dashboard_goal_reached"):d.totalRemaining===0?tx(`总进度已达到 ${formatMinutesFromHours(workspace.hourRule.total)}，正在确认达标状态。`,`The total has reached ${formatMinutesFromHours(workspace.hourRule.total)}; confirming completion status.`):t("dashboard_total_remaining",formatMinutesFromHours(d.totalRemaining))}
    </div>
  `,20);const breakdown=`<div class="col" style="gap:12px">
    <span class="title-large text-on-surface">${t("dashboard_breakdown")}</span>
    ${homeCard(`
      ${categoryMetric({title:t("dashboard_course_exercise"),value:workspace.progress.course,target:workspace.hourRule.courseRequired})}
      <div class="course-divider" style="margin:20px 0"></div>
      ${categoryMetric({title:t("dashboard_general_exercise"),value:workspace.progress.general,target:workspace.hourRule.generalRequired})}
    `)}
  </div>`;const proofTodos=Array.isArray(workspace.proofTodos)?workspace.proofTodos:[];const proofTodoRows=proofTodos.map(item=>{return`<button class="outlined-btn pressable" type="button" data-action="dashboard.openProofTodo" data-record-id="${esc(item.recordId||"")}" style="min-height:44px;width:100%;text-align:left">
      ${proofTodoContext(item)}
    </button>`}).join("");const proofTodoPanel=proofTodos.length?homeCard(`
    <div class="title-large text-on-surface">${tx("补证待办","Proof to-do")}</div>
    <div style="height:8px"></div>
    <div class="body-medium text-muted">${proofTodos.length?tx("选择下方记录，查看要求并为该次运动补充材料。","Select a record to review the request and add evidence for that exercise."):tx("当前没有需要补证的记录。","No records currently need supplementary evidence.")}</div>
    ${proofTodoRows?`<div style="height:12px"></div>${proofTodoRows}`:""}
    <div style="height:16px"></div>
    <button class="outlined-btn pressable" type="button" data-action="dashboard.openCheckIn" ${proofTodos.length?"":"disabled"} style="min-height:48px">${tx("打开补证待办","Open proof to-do")}</button>
  `):`<div class="home-proof-empty">${icon("check-circle",18)}<span>${tx("当前没有补证待办。","No supplementary evidence is needed right now.")}</span></div>`;return`<div class="tab-content col dashboard-content" style="gap:28px;padding-top:4px">
    ${header}
    ${resumePanel||todayPanel}
    ${joinPanel}
    ${overview}
    ${breakdown}
    ${proofTodoPanel}
  </div>`}export const dashboardActions={"dashboard.openNotifications":app=>{app.state.notificationSheetOpen=true;app.ui.notifications=null;app.render()},"dashboard.openCheckIn":app=>app.selectTab("checkin"),"dashboard.openProofTodo":(app,el)=>app.actions["checkin.selectProof"](app,el),"dashboard.scanJoin":app=>{app.ui.scan=null;app.openSub("scan",{})},"dashboard.enterCode":app=>{app.ui.enterCode=null;app.openSub("enterCode",{})}};
